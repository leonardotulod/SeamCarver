#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#include "functions.h"

using namespace std;

Pixel** createImage(int width, int height) {
  cout << "Start createImage... " << endl;
  
  // Create a one dimensional array on the heap of pointers to Pixels 
  //    that has width elements (i.e. the number of columns)
  Pixel** image = new Pixel*[width];
  
  bool fail = false;
  
  for (int i = 0; i < width; ++i) { // loop through each column
    // assign that column to a one dimensional array on the heap of Pixels
    //  that has height elements (i.e. the number of rows)
    image[i] = new Pixel[height];
    
    if (image[i] == nullptr) { // failed to allocate
      fail = true;
    }
  }
  
  if (fail) { // if any allocation fails, clean up and avoid memory leak
    // deallocate any arrays created in for loop
    for (int i = 0; i < width; ++i) {
      delete [] image[i]; // deleting nullptr is not a problem
    }
    delete [] image; // dlete array of pointers
    return nullptr;
  }
  
  // initialize cells
  //cout << "Initializing cells..." << endl;
  for (int row = 0; row < height; ++row) {
    for (int col=0; col < width; ++col) {
      //cout << "(" << col << ", " << row << ")" << endl;
      image[col][row] = { 0, 0, 0 };
    }
  }
  cout << "End createImage... ";
  cout<<endl;
  return image;
}

void deleteImage(Pixel** image, int width) { // deleted the 3rd parameter of int height maybe fix later
  cout << "Start deleteImage..." << endl;
  // avoid memory leak by deleting the array
  for (int i=0; i<width; ++i) {
    delete [] image[i]; // delete each individual array placed on the heap
  }
  delete [] image;
  image = nullptr;
}


int* createSeam(int length) { 
  int count = 0;
  int* seam = new int [length];
  for (int i = 0; i < length; i++) {
	  seam[i] = 0;
	  count +=1;
  }
  if (count > 0 ) {
	return seam;
  }
	return nullptr;
}

void deleteSeam(int* seam) {
	delete [] seam;
	seam = nullptr;
}

bool loadImage(string filename, Pixel** image, int width, int height) {
	ifstream ifs(filename);
	if (!ifs.is_open()) {
		cout << "Error: failed to open input file - " << filename;
		cout<< endl;
		return false;
	}
	char type[3];
	ifs >> type;
	if ((type[1] != '3') || (toupper(type[0]) != 'P')) {
		cout << "Error: type is " << type << " instead of P3";
		cout<<endl;
		return false;
	}
	
	int w = 0;
	int h = 0;
	ifs >> w;
	if (ifs.fail()) {
		cout << "Error: read non-integer value";
		cout << endl;
		return false;
	}
	else if (0 > w) {
		cout << "Error: read non-integer value" << endl; // check if that's right DELETE THIS 
		return false;
	}
	
	else if (width != w) {
		cout << "Error: input width (" << width << ") does not match value in file (" << w << ")" << endl;
		return false;
}

	ifs >> h;
	if (ifs.fail()) {
		cout << "Error: read non-integer value" << endl;
		return false;
	}
	else if (0 > h) {
		cout << "Error: read non-integer value" << endl; 
		return false;
	}
	
	else if (height != h) {
		cout << "Error: input height (" << height << ") does not match value in file (" << h << ")" << endl;
		return false;
	}
	int maxColor = 0;
	ifs >> maxColor;
	if (255 != maxColor) {
		cout << "Error: file is not using RGB color values." << endl; 
		return false;
	}
	int red = 0;
	int green = 0;
	int blue = 0;
	int i;
	int k;
	int pixelsTotal = (height * width);
	int counter = 0;
		string blankCheck = "";
	for (i = 0; i < height; i++) {
		for(k = 0; k < width ; k++) {
			ifs>> red;
			if (ifs.fail() && (ifs.eof()) ) {
				cout << " Error: not enough color values";
				cout << endl;
				return false;
			}
			else if (ifs.eof()) {
				return true;
			}
			else if (ifs.fail()) {
				cout << "Error: read non-integer value";
				cout << endl;
				return false;
			}
			else if ((red > 255) || (red < 0)) {
				cout << "Error: invalid color value " << red;
				cout << endl;
				return false;
			}
			else {
				image[k][i].r = red;
			}
			
			ifs>> green;
			
			if (ifs.fail() && (ifs.eof())) {
				cout << " Error: not enough color values";
				cout << endl;
				return false;
			}
			else if (ifs.eof()) {
				return true;
			}
			else if (ifs.fail()) {
				cout << "Error: read non-integer value";
				cout << endl;
				return false;
			}
			else if (green > 255 ||  green < 0) {
				cout << "Error: invalid color value " << green << endl;
				return false;
			}
			else {
				image[k][i].g = green;
			}
			
			ifs>> blue;
			if (ifs.fail() &&  (ifs.eof())) {
				cout << " Error: not enough color values" << endl;
				return false;
			}
			else if (ifs.eof()) {
				return true;
			}
			else if (ifs.fail()) {
				cout << "Error: read non-integer value" << endl;
				return false;
			}
			else if (blue > 255  || blue < 0 ) {
				cout << "Error: invalid color value " << blue << endl;
				return false;
			}
			else {
				image[k][i].b = blue;
			}
			
			if ((counter - 1) == (pixelsTotal * 3)) {
				ifs >> blankCheck;
				if (!ifs.fail()) {
					return true;
				}
			}
		}
	}
	int valueOver = 0;
	ifs >> valueOver;
	if (ifs.good()) {
		cout << "Error: too many color values" << endl;
		return false;
	}
	return true;
}	


bool outputImage(string filename, Pixel** image, int width, int height) {
	int i;
	int k;
	ofstream fout(filename); 
	if (!fout.is_open()) {
		cout << "Error: failed to open output file " << filename << endl;
		return false;
	}
	
	fout << "P3";
	fout << endl;
	fout << width;
	fout << endl;
	fout << height;
	fout << endl;
	fout << 255;
	fout << endl;
	
	for (i = 0; i < height; i++) {
		for (k = 0; k < width; k++) {
			fout << image [k][i].r << " ";
			fout << image [k][i].g << " ";
			fout << image [k][i].b << " ";
		}
	}
	return true;
}

int energy(Pixel** image, int x, int y, int width, int height) {
	int rx = 0;
	int gx = 0;
	int bx = 0;
	int ry = 0;
	int gy = 0;
	int by = 0;
	if (x == width - 1 || x == 0  || y ==  height - 1 || 0 == y) {
		if ( 0 == y && 0 == x ) {
			rx = image[1][y].r - image[width - 1][y].r;
			gx = image[1][y].g - image[width - 1][y].g;
			bx = image[1][y].b - image[width - 1][y].b;
			
			ry = image[0][height - 1].r - image [0][1].r;
			gy = image[0][height - 1].g - image [0][1].g;
			by = image[0][height - 1].b - image [0][1].b;
		}
		
		else if (x == width - 1 && y == 0) {			
			rx = image[0][0].r - image[x - 1][0].r;
			gx = image[0][0].g - image[x - 1][0].g;
			bx = image[0][0].b - image[x - 1][0].b;
			
			ry = image[x][height - 1].r - image [x][1].r;
			gy = image[x][height - 1].g - image [x][1].g;
			by = image[x][height - 1].b - image [x][1].b;
		}
		
		else if (x == 0 && y == height - 1) {  
			rx = image[1][y].r - image[width - 1][y].r;
			gx = image[1][y].g - image[width - 1][y].g;
			bx = image[1][y].b - image[width - 1][y].b;
			ry = image[0][y - 1].r - image [0][0].r;
			gy = image[0][y - 1].g - image [0][0].g;
			by = image[0][y - 1].b - image [0][0].b;
		}
		
		else if (x == width - 1 && y == height - 1) { 
			rx = image[0][y].r - image[x - 1][y].r;
			gx = image[0][y].g - image[x - 1][y].g;
			bx = image[0][y].b - image[x - 1][y].b;
			ry = image[x][y - 1].r - image [x][0].r;
			gy = image[x][y - 1].g - image [x][0].g;
			by = image[x][y - 1].b - image [x][0].b;
		}
		
		else if (0 == x) {
			rx = image[x+1][y].r - image[width - 1][y].r;
			gx = image[x+1][y].g - image[width - 1][y].g;
			bx = image[x+1][y].b - image[width - 1][y].b;
			ry = image[x][y - 1].r - image [x][y+1].r;
			gy = image[x][y - 1].g - image [x][y+1].g;
			by = image[x][y - 1].b - image [x][y+1].b;
		}	
		
		else if (0 == y) {
			rx = image[x + 1][0].r - image[x - 1][0].r;
			gx = image[x + 1][0].g - image[x - 1][0].g;
			bx = image[x + 1][0].b - image[x - 1][0].b;
			ry = image[x][height - 1].r - image [x][1].r;
			gy = image[x][height - 1].g - image [x][1].g;
			by = image[x][height - 1].b - image [x][1].b;
		}
		

		
		else if ( width - 1 == x ) {
			rx = image[0][y].r - image[width - 2][y].r;
			gx = image[0][y].g - image[width - 2][y].g;
			bx = image[0][y].b - image[width - 2][y].b;
			ry = image[x][y - 1].r - image [x][1+y].r;
			gy = image[x][y - 1].g - image [x][1+y].g;
			by = image[x][y - 1].b - image [x][1+y].b;
		}
		
		else if ( height - 1 == y ) {	
			rx = image[x+1][y].r - image[x - 1][y].r;
			gx = image[x+1][y].g - image[x - 1][y].g;
			bx = image[x+1][y].b - image[x - 1][y].b;
			ry = image[x][y - 1].r - image [x][0].r;
			gy = image[x][y - 1].g - image [x][0].g;
			by = image[x][y - 1].b - image [x][0].b;
		}
	}
		
	else {
		rx = image[x + 1][y].r - image[x - 1][y].r;
		gx = image[x + 1][y].g - image[x - 1][y].g;
		bx = image[x + 1][y].b - image[x - 1][y].b;	
		ry = image[x][y + 1].r - image [x][y - 1].r;
		gy = image[x][y + 1].g - image [x][y - 1].g;
		by = image[x][y + 1].b - image [x][y - 1].b;
		}
	int Xenergy = 0;
	int Yenergy = 0;
	Xenergy = (rx * rx) + (gx * gx) + (bx * bx);
	Yenergy = (ry * ry) + (gy * gy) + (by * by);
	int energyTotal = 0;
	energyTotal = Xenergy +Yenergy;
	return energyTotal;
}

int loadVerticalSeam(Pixel** image, int start_col, int width, int height, int* seam) {
	
	int i;
    int column = start_col;
	int right = 0;
	int left = 0;
	int down = 0;
    seam[0] = start_col;
    int energyTotal = 0;
    energyTotal = energyTotal + energy(image, column, 0, width, height);
    
    
    for(i = 1; i < height; ++i){
        if(0 == column){
            down = energy(image, column, i, width, height);
            right = energy(image, column+1, i, width, height);

            if(right == down ||  right > down ){
                energyTotal = energyTotal + down;
                seam[i] = column;
            }
            else {
				
                energyTotal += right;
				
                column++;
				
                seam[i] = column;
            }
        }
            else if(width-1  == column){
            down = energy(image, column, i, width, height);
            left = energy(image, column-1, i, width, height);
            if(down < left || down == left){
                energyTotal = energyTotal + down;
                seam[i] = column;
				
            }
            else {
                energyTotal += left;
				
                column -= 1;
				
                seam[i] = column;
            }
        }
            else {
            down = energy(image, column, i, width, height);
			
            left = energy(image, column-1, i, width, height);
			
            right = energy(image, column+1, i, width, height);
			
            if(right > down &&  left > down){ 
				
                energyTotal = energyTotal + down;
				
                seam[i] = column;
            }
            else if(left < down && left < right){ 
				
                  energyTotal = energyTotal + left;
				  
                  seam[i] = column - 1;
				  
                  column -= 1 ;
				  
            }
            else if(right < down && right < left){ 
				
                energyTotal += right;
				
                seam[i] = column+1;
				
                column+=1;
				
            }
			
            else {
                if(left == down and right == down){
					
                    energyTotal = energyTotal + down;
					
                    seam[i] = column;
					
           
                }
            else if( right != down and down == left) {
				
                    energyTotal = energyTotal + down;
					
                    seam[i] = column;
					
                }
				
            else if(down != left && down == right) {
				
                    energyTotal = energyTotal + down;
					
                    seam[i] = column;
                }
				
            else if(left != down and left == right){
				
                    energyTotal = energyTotal + right;
					
                    seam[i] = column+1;
					
                    column+=1;
                } 
				
            }
			
        }
		
    } 
	
    return energyTotal;
} 

//----------------------------------------------------------------------------------------------------


int loadHorizontalSeam(Pixel** image, int start_row, int width, int height, int* seam) {
    int energyTotal = 0;
	int right = 0;
    int down = 0;
    int up = 0;
    int row = start_row;
	int i;
    seam[0] = start_row;
    energyTotal += energy(image, 0, row, width, height);
	
    for(i = 1; i < width; i++){
		
        if(row == 0){
			
            right = energy(image, i, row, width, height);
            down = energy(image, i, row+1, width, height);
			
            if(down > right or down == right){
                seam[i] = row;
                energyTotal = energyTotal + right;
            }
            else {
                row++;
                seam[i] = row;
                energyTotal = energyTotal + down;
            }
        }
            else if(height -1 == row){
            up = energy(image, i, row-1, width, height);
			
            right = energy(image, i, row, width, height);
            if(up > right  or up == right){
                seam[i] = row;
                energyTotal = energyTotal + right;
             
            }
            else {
                row-=1;
                seam[i] = row;
                energyTotal = energyTotal + up;
                
            }
			
        }



            else {
				
            right = energy(image, i, row, width, height);
            down = energy(image, i, row+1, width, height);
            up = energy(image, i, row-1, width, height);
            if(up > right and right < down){ 
                energyTotal = energyTotal + right;
                seam[i] = row;
				
            }
            else if( down < up and down < right){
				
                energyTotal = energyTotal + down;
				
                row++;
				
                seam[i] = row;
                
            }
            else if( up < down and up < right){
				
                energyTotal = energyTotal + up;
				
                row-=1;
                seam[i] = row;
         
            }
			
            else {
				
                if( up == right and right == down){
					
                    energyTotal += right;
					
                    seam[i] = row;
                   
                }
                else if( down == right and up != right) {
					
                    energyTotal += right;
					
                    seam[i] = row;
                }
                else if(up != right && up == down) {
					
                    energyTotal += up;
					
                    row-=1;
					
                    seam[i] = row;
					
                    
                }
                else if(right != down && right == up) {
					
                    energyTotal += right;
					
                    seam[i] = row;
					
                    
                } 
            } 
        } 
    } 
    return energyTotal;
} 

int* findMinVerticalSeam(Pixel** image, int width, int height) {
	
	int energy;
	
	int i;
	
	int j;
	
    int* seamMin = createSeam(height);
    
    int minEnergy = loadVerticalSeam(image, 0, width, height, seamMin); 
	
    for(i = 1; i < width; i++){ 
		
        int* seam = createSeam(height);
		
        energy = loadVerticalSeam(image, i, width, height, seam);
		
        if(minEnergy > energy){
		
			minEnergy = energy;
           
            for(j = 0; j < height; j++) {
				
                seamMin[j] = seam[j];
             
            }
			
        }
		
        deleteSeam(seam);
    }
	
    return seamMin;
}

int* findMinHorizontalSeam(Pixel** image, int width, int height) {
   
    int* seamMin = createSeam(width);
	
	int energy;
	 
    int minEnergy = loadHorizontalSeam(image, 0, width, height, seamMin);
	
	int i;
	
    for(i = 1; i < height; ++i){
        int* seam = createSeam(width);
		
        energy = loadHorizontalSeam(image, i, width, height, seam);
		
        if(minEnergy > energy){
          
            for(int i = 0; i < width; ++i){
                seamMin[i] = seam[i];
                //cout <<seam[i] <<endl;
            }
            minEnergy = energy;
        }
        deleteSeam(seam);
    }
    return seamMin;
}

void removeVerticalSeam(Pixel** image, int width, int height, int* verticalSeam) {
	int j = 0;
	int i = 0;
	
  for(i = 0; i < height; ++i){
	  
    int column = verticalSeam[i];
	
    for(j = column; j < width-1; ++j){
		
      image[j][i] = image[j+1][i];
	  
    }
  }
}

void removeHorizontalSeam(Pixel** image, int width, int height, int* horizontalSeam) {
	int i;
	int j;
	
    for(i = 0; i < width; ++i){
		
        int row = horizontalSeam[i];
		
        for(j = row; j < height-1; ++j){
			
            image[i][j] = image[i][j+1];
        }
    }
}

//end of functions 